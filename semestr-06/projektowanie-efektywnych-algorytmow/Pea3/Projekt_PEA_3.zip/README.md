# PEA Projekt 3 
- WYSWIETLAJ_PASEK_POSTEPU: 1/0, pokazuje pasek postepu.
- PLIK_WYNIKOWY: plik z raportem z testu pojedynczego pliku.
- PLIK_RAPORTU_GENEROWANEGO: plik z raportem z testu folderu.
- PLIK_KONWERGENCJI: plik z przebiegiem konwergencji.
- POWTORZENIA: ile razy liczyc ta sama instancje.

Tabu Search:
- TS_MAX_ITERACJI: limit iteracji.
- TS_ROZMIAR_LISTY: limit dlugosci listy tabu.
- TS_KADENCJA: na ile iteracji zakaz.
- TS_ASPIRACJA_KLASYCZNA: 1/0, klasyczna aspiracja.
- TS_UZYJ_UB: 1/0, start od heurystyki.
- TS_UZYJ_LB: 1/0, uzyj dolnego ograniczenia.
- TS_UB_METODA: NN albo RNN.

Tryb testow:
- TRYB_TESTOW: PLIK lub FOLDER.
- SCIEZKA_DO_FOLDERU: gdzie sa macierze (dla FOLDER).
- SCIEZKA_DO_PLIKU: plik z macierza (dla PLIK).


### 1) Szybki test jednego pliku

WYSWIETLAJ_PASEK_POSTEPU = 0
PLIK_WYNIKOWY = wyniki/raport_tabu.csv
PLIK_RAPORTU_GENEROWANEGO = wyniki/raport_generowane.csv
PLIK_KONWERGENCJI = wyniki/konwergencja.csv
POWTORZENIA = 1

TS_MAX_ITERACJI = 200
TS_ROZMIAR_LISTY = 200
TS_KADENCJA = 50
TS_ASPIRACJA_KLASYCZNA = 1
TS_UZYJ_UB = 0
TS_UZYJ_LB = 0
TS_UB_METODA = NN

TRYB_TESTOW = PLIK
SCIEZKA_DO_FOLDERU = dane/generowane/symetryczne/8
SCIEZKA_DO_PLIKU = dane/macierze_testowe/matrix_6x6.atsp

### 2) Szybki test folderu
WYSWIETLAJ_PASEK_POSTEPU = 1
PLIK_WYNIKOWY = wyniki/raport_tabu.csv
PLIK_RAPORTU_GENEROWANEGO = wyniki/raport_generowane.csv
PLIK_KONWERGENCJI = wyniki/konwergencja.csv
POWTORZENIA = 1

TS_MAX_ITERACJI = 200
TS_ROZMIAR_LISTY = 200
TS_KADENCJA = 50
TS_ASPIRACJA_KLASYCZNA = 1
TS_UZYJ_UB = 0
TS_UZYJ_LB = 0
TS_UB_METODA = NN

TRYB_TESTOW = FOLDER
SCIEZKA_DO_FOLDERU = dane/generowane/symetryczne/8
SCIEZKA_DO_PLIKU = dane/tsp_proste/sym/brazil58_prosty.txt

### 3) Szybki test z UB i LB
WYSWIETLAJ_PASEK_POSTEPU = 1
PLIK_WYNIKOWY = wyniki/raport_tabu.csv
PLIK_RAPORTU_GENEROWANEGO = wyniki/raport_generowane.csv
PLIK_KONWERGENCJI = wyniki/konwergencja.csv
POWTORZENIA = 1

TS_MAX_ITERACJI = 300
TS_ROZMIAR_LISTY = 300
TS_KADENCJA = 80
TS_ASPIRACJA_KLASYCZNA = 1
TS_UZYJ_UB = 1
TS_UZYJ_LB = 1
TS_UB_METODA = RNN

TRYB_TESTOW = PLIK
SCIEZKA_DO_FOLDERU = dane/generowane/symetryczne/8
SCIEZKA_DO_PLIKU = dane/tsp_proste/sym/gr17.tsp_prosty.txt
