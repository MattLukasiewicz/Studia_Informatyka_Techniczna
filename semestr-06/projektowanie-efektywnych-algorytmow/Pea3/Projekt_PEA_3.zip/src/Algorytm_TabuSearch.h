#ifndef ALGORYTM_TABUSEARCH_H
#define ALGORYTM_TABUSEARCH_H

#include <vector>
#include <string>

std::vector<int> szukaj_tabu(
    const std::vector<std::vector<int>>& graf, 
    int limit_iteracji, 
    int startowa_kadencja,
    int maksymalny_rozmiar_listy,
    const std::vector<int>& poczatkowa_trasa,
    int dolne_ograniczenie,
    bool uzyj_klasycznej_aspiracji,
    const std::string& nazwa_instancji = "",
    const std::string& plik_konwergencji = ""
);

#endif