#ifndef TESTY_GENEROWANE_H
#define TESTY_GENEROWANE_H

#include <string>
#include "WczytywanieKonfiguracji.h"

void przeprowadz_testy_generowane(const std::string& sciezka_do_folderu,
                                  const WczytywanieKonfiguracji& config,
                                  const std::string& plik_csv);

#endif
