#include "WczytywanieKonfiguracji.h"
#include <fstream>
#include <iostream>
#include <cctype>

using namespace std;

WczytywanieKonfiguracji::WczytywanieKonfiguracji() {
    wyswietlaj_pasek = false;
    plik_wynikowy = "";
    plik_raportu_generowanego = "";
    powtorzenia = 1;
    
    ts_max_iteracji = 0;
    ts_kadencja = 0;
    ts_rozmiar_listy = 100000; 
    ts_aspiracja_klasyczna = true;
    ts_uzyj_ub = false;
    ts_uzyj_lb = false;
    ts_ub_metoda = "NN";

    tryb_testow = "PLIK";
    sciezka_do_folderu = "";
    
    sciezka_do_pliku = "";
}

bool WczytywanieKonfiguracji::wczytaj_z_pliku(const string& nazwa_pliku) {
    ifstream plik(nazwa_pliku);

    if (!plik.is_open()) {
        cerr << "Nie mozna otworzyc  pliku configu: " << nazwa_pliku << endl;
        return false;
    }

    string klucz;
    string znak_rownosci;

    while (plik >> klucz) {
        if (klucz.substr(0, 2) == "//") {
            string reszta_linii;
            getline(plik, reszta_linii);
            continue;
        }

        plik >> znak_rownosci;

        if (klucz == "WYSWIETLAJ_PASEK_POSTEPU") {
            plik >> wyswietlaj_pasek;
        } else if (klucz == "PLIK_WYNIKOWY") {
            plik >> plik_wynikowy;
        } else if (klucz == "PLIK_RAPORTU_GENEROWANEGO") {
            plik >> plik_raportu_generowanego;
        } else if (klucz == "PLIK_KONWERGENCJI") {
            plik >> plik_konwergencji;
        } else if (klucz == "POWTORZENIA") {
            plik >> powtorzenia;
        } else if (klucz == "TS_MAX_ITERACJI") {
            plik >> ts_max_iteracji;
        }else if (klucz == "TS_ROZMIAR_LISTY") {
            plik >> ts_rozmiar_listy;  
        } else if (klucz == "TS_KADENCJA") {
            plik >> ts_kadencja;
        } else if (klucz == "TS_ASPIRACJA_KLASYCZNA") {
            plik >> ts_aspiracja_klasyczna;
        } else if (klucz == "TS_UZYJ_UB") {
            plik >> ts_uzyj_ub;
        } else if (klucz == "TS_UZYJ_LB") {
            plik >> ts_uzyj_lb;
        } else if (klucz == "TS_UB_METODA") {
            plik >> ts_ub_metoda;
            for (char& c : ts_ub_metoda) {
                c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
            }
        } else if (klucz == "TRYB_TESTOW") {
            plik >> tryb_testow;
            for (char& c : tryb_testow) {
                c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
            }
        } else if (klucz == "SCIEZKA_DO_FOLDERU") {
            plik >> sciezka_do_folderu;
        } else if (klucz == "SCIEZKA_DO_PLIKU") {
            plik >> sciezka_do_pliku;
        }
    }

    plik.close();
    return true;
}