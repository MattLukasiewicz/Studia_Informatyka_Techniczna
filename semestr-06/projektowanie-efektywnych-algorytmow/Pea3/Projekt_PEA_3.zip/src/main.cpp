#include <iostream>
#include "WczytywanieKonfiguracji.h"
#include "Testy_Tabu.h"
#include "Testy_Generowane.h"

using namespace std;

int main() {
    WczytywanieKonfiguracji config;
    if (!config.wczytaj_z_pliku("config.txt")) {
        return 1;
    }

    cout << "PEA Projekt 3: Tabu Search" << endl;
    
    if (config.tryb_testow == "FOLDER") {
        przeprowadz_testy_generowane(config.sciezka_do_folderu, config, config.plik_raportu_generowanego);
    } else {
        przeprowadz_testy(config.sciezka_do_pliku, config);
    }

    return 0;
}