#ifndef WCZYTYWANIEKONFIGURACJI_H
#define WCZYTYWANIEKONFIGURACJI_H

#include <string>

using namespace std;

class WczytywanieKonfiguracji {
public:
    bool wyswietlaj_pasek;
    string plik_wynikowy;
    string plik_raportu_generowanego;
    string plik_konwergencji;
    int powtorzenia;

    int ts_max_iteracji;
    int ts_kadencja;
    int ts_rozmiar_listy; 
    bool ts_aspiracja_klasyczna;
    bool ts_uzyj_ub;
    bool ts_uzyj_lb;
    string ts_ub_metoda;

    string tryb_testow;
    string sciezka_do_folderu;

    string sciezka_do_pliku;

    WczytywanieKonfiguracji();
    bool wczytaj_z_pliku(const string& nazwa_pliku);
};

#endif