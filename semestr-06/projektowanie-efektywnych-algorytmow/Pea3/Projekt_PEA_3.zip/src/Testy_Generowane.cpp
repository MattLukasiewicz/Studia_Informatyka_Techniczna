#include "Testy_Generowane.h"
#include "Wczytywanie_Macierzy.h"
#include "Algorytm_MST.h"
#include "Algorytm_NN_i_RNN.h"
#include "Algorytm_TabuSearch.h"
#include "Stoper.h"
#include "Pasek_postepu.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <vector>

using namespace std;

int policz_koszt_generowane(const vector<int>& trasa, const vector<vector<int>>& graf) {
    int suma = 0;
    int n = trasa.size();
    for (int i = 0; i < n - 1; ++i) suma += graf[trasa[i]][trasa[i + 1]];
    suma += graf[trasa[n - 1]][trasa[0]];
    return suma;
}

void przeprowadz_testy_generowane(const string& sciezka_do_folderu,
                                  const WczytywanieKonfiguracji& config,
                                  const string& plik_csv) {
    namespace fs = std::filesystem;

    if (!fs::exists(sciezka_do_folderu) || !fs::is_directory(sciezka_do_folderu)) {
        cerr << "Blad: Nieprawidlowy folder: " << sciezka_do_folderu << "\n";
        return;
    }

    // NAPRAWIONE: Zmienna to 'plik', a 'plik_csv' to tylko std::string
    ofstream plik(plik_csv, ios::app);
    plik.seekp(0, ios::end);
    if (plik.tellp() == 0) {
        plik << "Plik;N;Optimum;Powtorzenia;Sredni_Koszt;Sredni_Blad_Proc;Sredni_Czas_ms;Iteracje;RozmiarListy;Kadencja;UB_On;LB_On;AspKlasyczna_On\n";
    }

    double suma_srednich_czasow = 0.0;
    double suma_srednich_kosztow = 0.0;
    double suma_srednich_bledow = 0.0;
    int liczba_z_optymalnym = 0;
    int najlepszy_znaleziony = numeric_limits<int>::max();
    int liczba_macierzy = 0;
    int n_wspolny = -1;

    vector<fs::path> pliki;
    for (const auto& entry : fs::directory_iterator(sciezka_do_folderu)) {
        if (entry.is_regular_file()) {
            pliki.push_back(entry.path());
        }
    }

    if (pliki.empty()) {
        cerr << "Blad: Brak plikow w folderze: " << sciezka_do_folderu << "\n";
        return;
    }

    pokazPostep(config.wyswietlaj_pasek, 0, static_cast<int>(pliki.size()), "Badanie folderu");

    for (size_t idx = 0; idx < pliki.size(); ++idx) {
        const auto& sciezka = pliki[idx].string();
        Macierz macierz = Wczytywanie_Macierzy::wczytajMacierz(sciezka);
        if (macierz.dane.empty()) {
            pokazPostep(config.wyswietlaj_pasek, static_cast<int>(idx + 1), static_cast<int>(pliki.size()), "Badanie folderu");
            continue;
        }

        vector<vector<int>> graf = macierz.dane;
        int N = graf.size();
        if (n_wspolny == -1) n_wspolny = N;
        if (n_wspolny != N) {
            cerr << "Uwaga: Rozmiar macierzy inny niz oczekiwany w folderze: " << sciezka << "\n";
        }

        int optimum = (macierz.optymalnyKoszt > 0) ? macierz.optymalnyKoszt : -1;

        double suma_czasow_ms = 0.0;
        long long suma_kosztow = 0;
        int najlepszy_lokalny = numeric_limits<int>::max();

        for (int i = 0; i < config.powtorzenia; i++) {
            int dolne_ograniczenie = -1;
            if (config.ts_uzyj_lb) {
                dolne_ograniczenie = oblicz_LB_MST(graf);
            }

            vector<int> trasa_startowa;
            if (config.ts_uzyj_ub) {
                if (config.ts_ub_metoda == "RNN") {
                    trasa_startowa = oblicz_UB_RNN(graf);
                } else {
                    trasa_startowa = oblicz_UB_NN(graf);
                }
            } else {
                trasa_startowa.resize(N);
                iota(trasa_startowa.begin(), trasa_startowa.end(), 0);
            }

            if (static_cast<int>(trasa_startowa.size()) != N) {
                trasa_startowa.resize(N);
                iota(trasa_startowa.begin(), trasa_startowa.end(), 0);
            }

            Stoper stoper;
            stoper.start();

            vector<int> wynik_trasa = szukaj_tabu(
            graf, config.ts_max_iteracji, config.ts_rozmiar_listy, config.ts_kadencja, 
            trasa_startowa, dolne_ograniczenie, 
            config.ts_aspiracja_klasyczna,
            sciezka, "" // <-- Uwaga, konwergencja folderowa może być pusta
            );

            stoper.stop();

            double czas_ms = stoper.pobierzCzasMs();
            int koszt = policz_koszt_generowane(wynik_trasa, graf);

            suma_czasow_ms += czas_ms;
            suma_kosztow += koszt;
            if (koszt < najlepszy_lokalny) najlepszy_lokalny = koszt;
        }

        double sredni_czas = suma_czasow_ms / config.powtorzenia;
        double sredni_koszt = static_cast<double>(suma_kosztow) / config.powtorzenia;
        double sredni_blad = (optimum > 0) ? ((sredni_koszt - optimum) / optimum) * 100.0 : 0.0;

        suma_srednich_czasow += sredni_czas;
        suma_srednich_kosztow += sredni_koszt;
        if (optimum > 0) {
            suma_srednich_bledow += sredni_blad;
            liczba_z_optymalnym++;
        }
        if (najlepszy_lokalny < najlepszy_znaleziony) najlepszy_znaleziony = najlepszy_lokalny;
        liczba_macierzy++;

        // NAPRAWIONE: plik << zamiast plik_csv <<
        plik << sciezka << ";" << N << ";" << optimum << ";" << config.powtorzenia << ";" 
             << sredni_koszt << ";" << sredni_blad << ";" << sredni_czas << ";" 
             << config.ts_max_iteracji << ";" << config.ts_rozmiar_listy << ";" << config.ts_kadencja << ";" 
             << config.ts_uzyj_ub << ";" << config.ts_uzyj_lb << ";" 
             << config.ts_aspiracja_klasyczna << "\n";
             
        pokazPostep(config.wyswietlaj_pasek, static_cast<int>(idx + 1), static_cast<int>(pliki.size()), "Badanie folderu");
    }

    if (liczba_macierzy == 0) {
        cerr << "Blad: Brak poprawnie wczytanych macierzy w folderze: " << sciezka_do_folderu << "\n";
        return;
    }

    double sredni_czas_folder = suma_srednich_czasow / liczba_macierzy;
    double sredni_blad_folder = (liczba_z_optymalnym > 0)
        ? (suma_srednich_bledow / liczba_z_optymalnym)
        : 0.0;

    plik << "FOLDER:" << sciezka_do_folderu << ";" << n_wspolny << ";" << -1 << ";" << config.powtorzenia << ";"
         << sredni_blad_folder << ";" << sredni_czas_folder << ";"
         << config.ts_max_iteracji << ";" << config.ts_kadencja << ";" // TU UŻYWA KADENCJI, MOŻNA DODAĆ ROZMIAR
         << config.ts_uzyj_ub << ";" << config.ts_uzyj_lb << ";"
         << config.ts_aspiracja_klasyczna << "\n";

    plik.close();

    if (config.wyswietlaj_pasek) cout << "\n";
    cout << "Zakonczono folder: " << sciezka_do_folderu
         << " | Najlepszy koszt: " << najlepszy_znaleziony
         << " | Sredni czas: " << sredni_czas_folder
         << "\n";
}