#!/usr/bin/env python3
import sys

from glfw.GLFW import *

from OpenGL.GL import *
from OpenGL.GLU import *
import numpy
import math
import random

N = 20
R = 5.0  # Duży promień Torusa
r = 4  # Mały promień Torusa


# Funkcja generująca wierzchołki Torusa i kolory
def torus(punkty_n, R_duze, r_male):
    tab = numpy.zeros((punkty_n, punkty_n, 3))
    tab_kolorow = numpy.zeros((punkty_n, punkty_n, 3))


    u_values = numpy.linspace(0.0, 1.0, punkty_n)
    v_values = numpy.linspace(0.0, 1.0, punkty_n)

    # Obliczenie i zapisanie wartości x, y, z w tablicy
    for i in range(punkty_n):
        for j in range(punkty_n):
            # Parametry u i v w zakresie [0, 1]
            u = u_values[i]
            v = v_values[j]

            # Wzory parametryczne dla Torusa
            # Używamy 2*pi*u i 2*pi*v zgodnie z definicją (u,v w [0,1])

            x = (R_duze + r_male * math.cos(2 * math.pi * v)) * math.cos(2 * math.pi * u)
            y = (R_duze + r_male * math.cos(2 * math.pi * v)) * math.sin(2 * math.pi * u)
            z = r_male * math.sin(2 * math.pi * v)

            # Zapisanie wierzchołka i losowego koloru
            tab[i][j][0] = x
            tab[i][j][1] = y
            tab[i][j][2] = z

            r_col = random.random()
            g_col = random.random()
            b_col = random.random()
            tab_kolorow[i][j][0] = r_col
            tab_kolorow[i][j][1] = g_col
            tab_kolorow[i][j][2] = b_col

    return tab, tab_kolorow



wierzcholki, kolory = torus(N, R, r)


def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glEnable(GL_DEPTH_TEST)


def shutdown():
    pass


def axes():
    glBegin(GL_LINES)

    glColor3f(1.0, 0.0, 0.0)
    glVertex3f(-5.0, 0.0, 0.0)
    glVertex3f(5.0, 0.0, 0.0)

    glColor3f(0.0, 1.0, 0.0)
    glVertex3f(0.0, -5.0, 0.0)
    glVertex3f(0.0, 5.0, 0.0)

    glColor3f(0.0, 0.0, 1.0)
    glVertex3f(0.0, 0.0, -5.0)
    glVertex3f(0.0, 0.0, 5.0)

    glEnd()


# Funkcja spin z prezentacji
def spin(angle):
    glRotatef(angle, 1.0, 0.0, 0.0)
    glRotatef(angle, 0.0, 1.0, 0.0)
    glRotatef(angle, 0.0, 0.0, 1.0)


def render(time):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    angle = time * 180 / math.pi
    spin(angle)

    axes()

    # Rysowanie paska trójkątów (GL_TRIANGLE_STRIP)
    # Dla Torusa potrzebujemy zawinąć siatkę w OBU kierunkach.
    # Warstwy Torusa idą w kierunku U (indeks i).

    for i in range(N):

        glBegin(GL_TRIANGLE_STRIP)

        # Rysujemy pierścień w kierunku V (indeks j).
        # Warstwa 'i' łączy się z warstwą 'i_next'.
        i_next = (i + 1) % N  # Zawinięcie w kierunku U

        for j in range(N):
            # 1. Wierzchołek P(i, j)
            glColor3fv(kolory[i][j])
            glVertex3fv(wierzcholki[i][j])

            # 2. Wierzchołek P(i_next, j)
            glColor3fv(kolory[i_next][j])
            glVertex3fv(wierzcholki[i_next][j])

        # Aby zamknąć pierścień w kierunku V (indeks j),
        # powtarzamy dwa pierwsze wierzchołki paska (dla j=0)

        # Powtarzamy P(i, 0)
        glColor3fv(kolory[i][0])
        glVertex3fv(wierzcholki[i][0])

        # Powtarzamy P(i_next, 0)
        glColor3fv(kolory[i_next][0])
        glVertex3fv(wierzcholki[i_next][0])

        glEnd()

    glFlush()



def update_viewport(window, width, height):
    if width == 0:
        width = 1
    if height == 0:
        height = 1
    aspect_ratio = width / height

    glMatrixMode(GL_PROJECTION)
    glViewport(0, 0, width, height)
    glLoadIdentity()

    # Zwiększamy zakres rysowania
    if width <= height:
        glOrtho(-10.0, 10.0, -10.0 / aspect_ratio, 10.0 / aspect_ratio, 10.0, -10.0)
    else:
        glOrtho(-10.0 * aspect_ratio, 10.0 * aspect_ratio, -10.0, 10.0, 10.0, -10.0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def main():
    if not glfwInit():
        sys.exit(-1)

    window = glfwCreateWindow(400, 400, __file__, None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSwapInterval(1)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    shutdown()

    glfwTerminate()


if __name__ == '__main__':
    main()