#!/usr/bin/env python3
import sys

from glfw.GLFW import *

from OpenGL.GL import *
from OpenGL.GLU import *
import numpy
import math
import random  # Dodajemy moduł random

N = 20


def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glEnable(GL_DEPTH_TEST)


def shutdown():
    pass


def axes():
    glBegin(GL_LINES)

    glColor3f(1.0, 0.0, 0.0)
    glVertex3f(-5.0, 0.0, 0.0)
    glVertex3f(5.0, 0.0, 0.0)

    glColor3f(0.0, 1.0, 0.0)
    glVertex3f(0.0, -5.0, 0.0)
    glVertex3f(0.0, 5.0, 0.0)

    glColor3f(0.0, 0.0, 1.0)
    glVertex3f(0.0, 0.0, -5.0)
    glVertex3f(0.0, 0.0, 5.0)

    glEnd()


def jajko(punkty_n):
    tab = numpy.zeros((punkty_n, punkty_n, 3))
    tab_kolorow = numpy.zeros((punkty_n, punkty_n, 3))  # Nowa tablica na kolory

    # tablica n elementowa wypelniona wartosciami od 0 do 1
    u_values = numpy.linspace(0.0, 1.0, punkty_n)
    v_values = numpy.linspace(0.0, 1.0, punkty_n)

    # Obliczenie i zapisanie wartości x, y, z w tablicy
    for i in range(punkty_n):
        for j in range(punkty_n):
            u = u_values[i]
            v = v_values[j]

            # Wzory na jajko z prezentacji
            wielomian_u = (-90 * u ** 5 + 225 * u ** 4 - 270 * u ** 3 + 180 * u ** 2 - 45 * u)

            x = wielomian_u * math.cos(math.pi * v)
            y = 160 * u ** 4 - 320 * u ** 3 + 160 * u ** 2 - 5
            z = wielomian_u * math.sin(math.pi * v)

            # Zapisanie wierzchołka w tablicy
            tab[i][j][0] = x
            tab[i][j][1] = y
            tab[i][j][2] = z

            # Przypisanie losowego koloru do wierzchołka (raz na zawsze)
            # Użycie random.random() generuje floaty od 0.0 do 1.0.
            r = random.random()
            g = random.random()
            b = random.random()
            tab_kolorow[i][j][0] = r
            tab_kolorow[i][j][1] = g
            tab_kolorow[i][j][2] = b

    return tab, tab_kolorow  # Zwracamy dwie tablice



wierzcholki, kolory = jajko(N)


# Funkcja spin z prezentacji
def spin(angle):
    glRotatef(angle, 1.0, 0.0, 0.0)
    glRotatef(angle, 0.0, 1.0, 0.0)
    glRotatef(angle, 0.0, 0.0, 1.0)


def render(time):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    angle = time * 180 / math.pi
    spin(angle)

    axes()

    # Rysowanie paska trójkątów dla każdej warstwy u (indeks i)
    for i in range(N - 1):

        glBegin(GL_TRIANGLE_STRIP)

        # Iterujemy po wierzchołkach w kierunku v (indeks j)
        for j in range(N):
            # Wierzchołki tej warstwy: (i, j) i (i+1, j)

            # 1. Wierzchołek P(i, j)
            glColor3fv(kolory[i][j])
            glVertex3fv(wierzcholki[i][j])

            # 2. Wierzchołek P(i + 1, j)
            glColor3fv(kolory[i + 1][j])
            glVertex3fv(wierzcholki[i + 1][j])



        glEnd()

    glFlush()

def update_viewport(window, width, height):
    if width == 0:
        width = 1
    if height == 0:
        height = 1
    aspect_ratio = width / height

    glMatrixMode(GL_PROJECTION)
    glViewport(0, 0, width, height)
    glLoadIdentity()

    if width <= height:
        glOrtho(-7.5, 7.5, -7.5 / aspect_ratio, 7.5 / aspect_ratio, 7.5, -7.5)
    else:
        glOrtho(-7.5 * aspect_ratio, 7.5 * aspect_ratio, -7.5, 7.5, 7.5, -7.5)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def main():
    if not glfwInit():
        sys.exit(-1)

    window = glfwCreateWindow(400, 400, __file__, None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSwapInterval(1)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    shutdown()

    glfwTerminate()


if __name__ == '__main__':
    main()