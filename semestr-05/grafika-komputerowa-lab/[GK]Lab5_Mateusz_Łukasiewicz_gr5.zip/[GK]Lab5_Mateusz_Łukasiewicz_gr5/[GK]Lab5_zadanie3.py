#!/usr/bin/env python3
import sys
import math

from glfw.GLFW import *

from OpenGL.GL import *
from OpenGL.GLU import *

viewer = [0.0, 0.0, 10.0]

#Zmienne do sterowania położeniem światła
theta = 0.0
phi = 0.0  # Kąt elewacji (góra-dół)
R = 10.0  # Promień orbity światła
pix2angle = 1.0

left_mouse_button_pressed = 0
mouse_x_pos_old = 0
mouse_y_pos_old = 0  # Potrzebne do śledzenia ruchu myszy w pionie
delta_x = 0
delta_y = 0  #Różnica ruchu w pionie

mat_ambient = [1.0, 1.0, 1.0, 1.0]
mat_diffuse = [1.0, 1.0, 1.0, 1.0]
mat_specular = [1.0, 1.0, 1.0, 1.0]
mat_shininess = 20.0

light_ambient = [0.1, 0.1, 0.0, 1.0]
light_diffuse = [0.8, 0.8, 0.0, 1.0]
light_specular = [1.0, 1.0, 1.0, 1.0]
light_position = [0.0, 0.0, 10.0, 1.0]

# nowe światło (statyczne)
light_ambient1 = [0.0, 0.1, 0.0, 1.0]
light_diffuse1 = [0.0, 1.0, 0.0, 1.0]
light_specular1 = [1.0, 1.0, 1.0, 1.0]
light_position1 = [-10.0, 0.0, 10.0, 1.0]

att_constant = 1.0
att_linear = 0.05
att_quadratic = 0.001

selected_light_component = 0


def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glEnable(GL_DEPTH_TEST)

    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse)
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular)
    glMaterialf(GL_FRONT, GL_SHININESS, mat_shininess)

    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)
    glLightfv(GL_LIGHT0, GL_POSITION, light_position)

    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, att_constant)
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, att_linear)
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, att_quadratic)

    # nowe swiatlo
    glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient1)
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse1)
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular1)
    glLightfv(GL_LIGHT1, GL_POSITION, light_position1)

    glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, att_constant)
    glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, att_linear)
    glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, att_quadratic)

    glShadeModel(GL_SMOOTH)
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)


def shutdown():
    pass


def render(time):
    global theta
    global phi
    global light_position

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    gluLookAt(viewer[0], viewer[1], viewer[2],
              0.0, 0.0, 0.0, 0.0, 1.0, 0.0)

    if left_mouse_button_pressed:
        theta += delta_x * pix2angle
        phi += delta_y * pix2angle



    x_s = R * math.cos(theta * math.pi / 180) * math.cos(phi * math.pi / 180)
    y_s = R * math.sin(phi * math.pi / 180)
    z_s = R * math.sin(theta * math.pi / 180) * math.cos(phi * math.pi / 180)

    light_position = [x_s, y_s, z_s, 1.0]
    glLightfv(GL_LIGHT0, GL_POSITION, light_position)

    quadric = gluNewQuadric()
    gluQuadricDrawStyle(quadric, GLU_FILL)
    gluSphere(quadric, 3.0, 10, 10)
    gluDeleteQuadric(quadric)

    glPushMatrix()
    glTranslatef(x_s, y_s, z_s)


    glDisable(GL_LIGHTING)
    glColor3f(1.0, 1.0, 0.0)

    quad_light = gluNewQuadric()
    gluQuadricDrawStyle(quad_light, GLU_LINE)
    gluSphere(quad_light, 0.5, 6, 5)
    gluDeleteQuadric(quad_light)

    glEnable(GL_LIGHTING)
    glPopMatrix()

    glFlush()


def update_viewport(window, width, height):
    global pix2angle
    pix2angle = 360.0 / width

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()

    gluPerspective(70, 1.0, 0.1, 300.0)

    if width <= height:
        glViewport(0, int((height - width) / 2), width, width)
    else:
        glViewport(int((width - height) / 2), 0, height, height)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def keyboard_key_callback(window, key, scancode, action, mods):
    global selected_light_component
    global light_ambient, light_diffuse, light_specular

    if action == GLFW_PRESS or action == GLFW_REPEAT:
        if key == GLFW_KEY_ESCAPE:
            glfwSetWindowShouldClose(window, GLFW_TRUE)

        if key == GLFW_KEY_B:
            selected_light_component = 0
            print("Czerwony")

        if key == GLFW_KEY_N:
            selected_light_component = 1
            print("Zielony")

        if key == GLFW_KEY_M:
            selected_light_component = 2
            print("Niebieski")

        if key == GLFW_KEY_UP:
            light_ambient[selected_light_component] += 0.1
            light_diffuse[selected_light_component] += 0.1

            if light_ambient[selected_light_component] > 1.0:
                light_ambient[selected_light_component] = 1.0
            if light_diffuse[selected_light_component] > 1.0:
                light_diffuse[selected_light_component] = 1.0

        if key == GLFW_KEY_DOWN:
            light_ambient[selected_light_component] -= 0.1
            light_diffuse[selected_light_component] -= 0.1

            if light_ambient[selected_light_component] < 0.0:
                light_ambient[selected_light_component] = 0.0
            if light_diffuse[selected_light_component] < 0.0:
                light_diffuse[selected_light_component] = 0.0

        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)


def mouse_motion_callback(window, x_pos, y_pos):
    global delta_x, delta_y
    global mouse_x_pos_old, mouse_y_pos_old

    delta_x = x_pos - mouse_x_pos_old
    mouse_x_pos_old = x_pos

    # --- ZMIANA: Obsługa ruchu w osi Y ---
    delta_y = y_pos - mouse_y_pos_old
    mouse_y_pos_old = y_pos


def mouse_button_callback(window, button, action, mods):
    global left_mouse_button_pressed

    if button == GLFW_MOUSE_BUTTON_LEFT and action == GLFW_PRESS:
        left_mouse_button_pressed = 1
    else:
        left_mouse_button_pressed = 0


def main():
    if not glfwInit():
        sys.exit(-1)

    window = glfwCreateWindow(400, 400, __file__, None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSetKeyCallback(window, keyboard_key_callback)
    glfwSetCursorPosCallback(window, mouse_motion_callback)
    glfwSetMouseButtonCallback(window, mouse_button_callback)
    glfwSwapInterval(1)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    shutdown()

    glfwTerminate()


if __name__ == '__main__':
    main()