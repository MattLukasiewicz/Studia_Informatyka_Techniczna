#!/usr/bin/env python3
import sys
import math
import numpy as np
from glfw.GLFW import *
from OpenGL.GL import *
from OpenGL.GLU import *

N_EGG = 30

viewer = [0.0, 0.0, 10.0]

mat_ambient = [1.0, 1.0, 1.0, 1.0]
mat_diffuse = [1.0, 1.0, 1.0, 1.0]
mat_specular = [1.0, 1.0, 1.0, 1.0]
mat_shininess = 20.0

light_ambient = [0.1, 0.1, 0.1, 1.0]
light_diffuse = [0.8, 0.8, 0.8, 1.0]
light_specular = [1.0, 1.0, 1.0, 1.0]
light_position = [0.0, 0.0, 10.0, 1.0]

att_constant = 1.0
att_linear = 0.05
att_quadratic = 0.001

theta_light = 0.0
phi_light = 0.0
R_light = 10.0
left_mouse_button_pressed = 0
mouse_x_pos_old = 0
mouse_y_pos_old = 0
delta_x = 0
delta_y = 0


def compute_egg_data():
    # Tablice na dane
    vertices = np.zeros((N_EGG, N_EGG, 3), dtype=np.float32)
    normals = np.zeros((N_EGG, N_EGG, 3), dtype=np.float32)

    for i in range(N_EGG):
        u = i / (N_EGG - 1)
        u2 = u * u
        u3 = u2 * u
        u4 = u3 * u
        u5 = u4 * u

        for j in range(N_EGG):
            v = j / (N_EGG - 1)


            P_u = (-90 * u5 + 225 * u4 - 270 * u3 + 180 * u2 - 45 * u)

            x = P_u * math.cos(math.pi * v)
            y = 160 * u4 - 320 * u3 + 160 * u2 - 5
            z = P_u * math.sin(math.pi * v)

            vertices[i][j] = [x, y, z]

            P_u_deriv = -450 * u4 + 900 * u3 - 810 * u2 + 360 * u - 45

            xu = P_u_deriv * math.cos(math.pi * v)
            xv = -math.pi * P_u * math.sin(math.pi * v)

            yu = 640 * u3 - 960 * u2 + 320 * u
            yv = 0

            zu = P_u_deriv * math.sin(math.pi * v)
            zv = math.pi * P_u * math.cos(math.pi * v)

            nx = yu * zv - zu * yv
            ny = zu * xv - xu * zv
            nz = xu * yv - yu * xv

            length = math.sqrt(nx * nx + ny * ny + nz * nz)
            if length > 0:
                nx /= length
                ny /= length
                nz /= length



            normals[i][j] = [nx, ny, nz]

    return vertices, normals


egg_vertices, egg_normals = compute_egg_data()


def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glEnable(GL_DEPTH_TEST)

    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient)
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse)
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular)
    glMaterialf(GL_FRONT, GL_SHININESS, mat_shininess)

    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)
    glLightfv(GL_LIGHT0, GL_POSITION, light_position)

    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, att_constant)
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, att_linear)
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, att_quadratic)

    glShadeModel(GL_SMOOTH)
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)


def render(time):
    global theta_light, phi_light, light_position

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()

    gluLookAt(viewer[0], viewer[1], viewer[2],
              0.0, 0.0, 0.0, 0.0, 1.0, 0.0)


    if left_mouse_button_pressed:
        theta_light += delta_x * 0.5
        phi_light += delta_y * 0.5

    xs = R_light * math.cos(math.radians(theta_light)) * math.cos(math.radians(phi_light))
    ys = R_light * math.sin(math.radians(phi_light))
    zs = R_light * math.sin(math.radians(theta_light)) * math.cos(math.radians(phi_light))

    light_position = [xs, ys, zs, 1.0]
    glLightfv(GL_LIGHT0, GL_POSITION, light_position)

    glPushMatrix()
    glTranslatef(xs, ys, zs)
    glDisable(GL_LIGHTING)
    glColor3f(1.0, 1.0, 0.0)
    quad = gluNewQuadric()
    gluQuadricDrawStyle(quad, GLU_LINE)
    gluSphere(quad, 0.5, 6, 5)
    glEnable(GL_LIGHTING)
    glPopMatrix()


    for i in range(N_EGG - 1):
        glBegin(GL_TRIANGLES)
        for j in range(N_EGG - 1):
            # Normalne musza być przed Vertex
            glNormal3fv(egg_normals[i][j])
            glVertex3fv(egg_vertices[i][j])

            glNormal3fv(egg_normals[i + 1][j])
            glVertex3fv(egg_vertices[i + 1][j])

            glNormal3fv(egg_normals[i][j + 1])
            glVertex3fv(egg_vertices[i][j + 1])

            # Drugi trójkąt
            glNormal3fv(egg_normals[i][j + 1])
            glVertex3fv(egg_vertices[i][j + 1])

            glNormal3fv(egg_normals[i + 1][j])
            glVertex3fv(egg_vertices[i + 1][j])

            glNormal3fv(egg_normals[i + 1][j + 1])
            glVertex3fv(egg_vertices[i + 1][j + 1])
        glEnd()

    glFlush()


def update_viewport(window, width, height):
    if height == 0: height = 1
    aspect = width / height
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(70, aspect, 0.1, 300.0)
    glViewport(0, 0, width, height)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def mouse_motion_callback(window, x_pos, y_pos):
    global delta_x, delta_y, mouse_x_pos_old, mouse_y_pos_old
    delta_x = x_pos - mouse_x_pos_old
    delta_y = y_pos - mouse_y_pos_old
    mouse_x_pos_old = x_pos
    mouse_y_pos_old = y_pos


def mouse_button_callback(window, button, action, mods):
    global left_mouse_button_pressed
    if button == GLFW_MOUSE_BUTTON_LEFT:
        left_mouse_button_pressed = (action == GLFW_PRESS)


def main():
    if not glfwInit(): sys.exit(-1)
    window = glfwCreateWindow(600, 600, "Lab 5 - Zadanie 4.5 (Czyste)", None, None)
    if not window: glfwTerminate(); sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSetCursorPosCallback(window, mouse_motion_callback)
    glfwSetMouseButtonCallback(window, mouse_button_callback)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    glfwTerminate()


if __name__ == '__main__':
    main()