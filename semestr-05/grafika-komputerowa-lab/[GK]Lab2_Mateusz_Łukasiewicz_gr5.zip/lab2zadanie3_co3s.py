#!/usr/bin/env python3
import sys
import random
from glfw.GLFW import *

from OpenGL.GL import *
from OpenGL.GLU import *
kolor1 = (1.0, 0.0, 0.0)
kolor2 = (0.0, 1.0, 0.0)
czas_ostatniej_zmiany = 0.0

def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.5, 0.5, 0.5, 1.0)


def shutdown():
    pass

# Ta funkcja już nie losuje, tylko dostaje kolory w prezencie
def prostokat(x, y, a, b, d=0.0, kolor_tr1=(1,0,0), kolor_tr2=(0,1,0)):
    # ... (kod do obliczania rozmiaru zostaje)
    if d != 0.0:
        a = a * d
        b = b * d

    # Maluje pierwszy trójkąt farbą, którą dostała
    glBegin(GL_TRIANGLES)
    glColor3f(*kolor_tr1) # Używa pierwszej farby
    glVertex2f(x, y)
    # ... (reszta wierzchołków)
    glVertex2f(x, y + a)
    glVertex2f(x + b, y + a)
    glEnd()

    # Mójkąt drugą farbąaluje drugi tr
    glBegin(GL_TRIANGLES)
    glColor3f(*kolor_tr2) # Używa drugiej farby
    glVertex2f(x, y)
    # ... (reszta wików)erzchoł
    glVertex2f(x + b, y + a)
    glVertex2f(x + b, y)
    glEnd()

def render(time):
    global kolor1, kolor2, czas_ostatniej_zmiany

    # 1. Sprawdzamy, czy minęły 3 sekundy
    if time - czas_ostatniej_zmiany > 3.0:
        # 2. Jeśli tak, losujemy nowe farby do pudełek
        kolor1 = (random.random(), random.random(), random.random())
        kolor2 = (random.random(), random.random(), random.random())
        # i zerujemy stoper
        czas_ostatniej_zmiany = time

    # 4. Malujemy prostokąt, dając mu farby z pudełek
    glClear(GL_COLOR_BUFFER_BIT)
    prostokat(20, 30, 40, 50, 1.2, kolor1, kolor2)
    glFlush()

def update_viewport(window, width, height):
    if width == 0:
        width = 1
    if height == 0:
        height = 1
    aspect_ratio = width / height

    glMatrixMode(GL_PROJECTION)
    glViewport(0, 0, width, height)
    glLoadIdentity()

    if width <= height:
        glOrtho(-100.0, 100.0, -100.0 / aspect_ratio, 100.0 / aspect_ratio,
                1.0, -1.0)
    else:
        glOrtho(-100.0 * aspect_ratio, 100.0 * aspect_ratio, -100.0, 100.0,
                1.0, -1.0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def main():
    if not glfwInit():
        sys.exit(-1)

    window = glfwCreateWindow(400, 400, __file__, None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSwapInterval(1)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    shutdown()

    glfwTerminate()


if __name__ == '__main__':
    main()
