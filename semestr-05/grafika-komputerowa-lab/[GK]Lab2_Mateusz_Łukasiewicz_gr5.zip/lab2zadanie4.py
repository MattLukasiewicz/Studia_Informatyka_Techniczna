#!/usr/bin/env python3
import sys
import random
from glfw.GLFW import *

from OpenGL.GL import *
from OpenGL.GLU import *


def startup():
    update_viewport(None, 400, 400)
    glClearColor(0.5, 0.5, 0.5, 1.0)


def shutdown():
    pass

def prostokat(x,y,a,b,d = 0.0):
    if d!=0.0:
        a=a*d
        b=b*d

    #seed1=random.random()
    #random.seed(seed1)
    red = random.random()
    green = random.random()
    blue = random.random()


    glBegin(GL_TRIANGLES)
    glColor3f(red, green, blue)
    glVertex2f(x, y)
    glVertex2f(x,y+a)
    glVertex2f(x+b,y+a)
    glEnd()



    red = random.random()
    green = random.random()
    blue = random.random()


    glBegin(GL_TRIANGLES)
    glColor3f(red, green, blue)
    glVertex2f(x, y)
    glVertex2f(x+b, y + a)
    glVertex2f(x + b, y)
    glEnd()

def rysuj_dywan(x, y, rozmiar, poziom):
    if poziom == 0:
        prostokat(x, y, rozmiar, rozmiar)
    else:
        #dziele prostokat na 3 i w kazdym bedzie nowy poziom
        nowy_rozmiar = rozmiar / 3.0
        poziom_nizej = poziom - 1

        # wywołuje funkcję dla 8 mniejszych prostoikątów
        # Górny rząd
        rysuj_dywan(x, y + 2 * nowy_rozmiar, nowy_rozmiar, poziom_nizej)
        rysuj_dywan(x + nowy_rozmiar, y + 2 * nowy_rozmiar, nowy_rozmiar, poziom_nizej)
        rysuj_dywan(x + 2 * nowy_rozmiar, y + 2 * nowy_rozmiar, nowy_rozmiar, poziom_nizej)
        # Dolny rząd
        rysuj_dywan(x, y, nowy_rozmiar, poziom_nizej)
        rysuj_dywan(x + nowy_rozmiar, y, nowy_rozmiar, poziom_nizej)
        rysuj_dywan(x + 2 * nowy_rozmiar, y, nowy_rozmiar, poziom_nizej)
        # Środkowy rząd
        rysuj_dywan(x, y + nowy_rozmiar, nowy_rozmiar, poziom_nizej)
        # Prawy środkowy
        rysuj_dywan(x + 2 * nowy_rozmiar, y + nowy_rozmiar, nowy_rozmiar, poziom_nizej)


stopien_samopodobienstwa  = 3

def render(time):
    glClear(GL_COLOR_BUFFER_BIT)
    rysuj_dywan(-50.0, -50.0, 100.0, stopien_samopodobienstwa)
    glFlush()


def update_viewport(window, width, height):
    if width == 0:
        width = 1
    if height == 0:
        height = 1
    aspect_ratio = width / height

    glMatrixMode(GL_PROJECTION)
    glViewport(0, 0, width, height)
    glLoadIdentity()

    if width <= height:
        glOrtho(-100.0, 100.0, -100.0 / aspect_ratio, 100.0 / aspect_ratio,
                1.0, -1.0)
    else:
        glOrtho(-100.0 * aspect_ratio, 100.0 * aspect_ratio, -100.0, 100.0,
                1.0, -1.0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()


def main():
    if not glfwInit():
        sys.exit(-1)

    window = glfwCreateWindow(400, 400, __file__, None, None)
    if not window:
        glfwTerminate()
        sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSwapInterval(1)

    startup()
    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    shutdown()

    glfwTerminate()


if __name__ == '__main__':
    main()
