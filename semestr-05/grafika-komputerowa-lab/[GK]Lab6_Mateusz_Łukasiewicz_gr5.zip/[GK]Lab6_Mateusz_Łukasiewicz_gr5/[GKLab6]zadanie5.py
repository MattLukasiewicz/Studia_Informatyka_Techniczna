#!/usr/bin/env python3
import sys
import math
import numpy as np
from glfw.GLFW import *
from OpenGL.GL import *
from OpenGL.GLU import *
from PIL import Image

TEXTURE_FILES = ["tekstura.tga", "vader.tga", "D2_t.tga", "N2_t.tga"]

N_EGG = 30

theta = 0.0
phi = 0.0
mouse_x_old = 0
mouse_y_old = 0
left_mouse_down = False

texture_ids = []
current_texture_index = 0

vertices = np.zeros((N_EGG, N_EGG, 3), dtype=np.float32)
normals = np.zeros((N_EGG, N_EGG, 3), dtype=np.float32)
tex_coords = np.zeros((N_EGG, N_EGG, 2), dtype=np.float32)


def compute_egg():
    for i in range(N_EGG):
        u = i / (N_EGG - 1)
        tex_u = u

        u2 = u * u;
        u3 = u2 * u;
        u4 = u3 * u;
        u5 = u4 * u

        for j in range(N_EGG):
            v = j / (N_EGG - 1)
            tex_v = v

            P_u = (-90 * u5 + 225 * u4 - 270 * u3 + 180 * u2 - 45 * u)
            x = P_u * math.cos(math.pi * v)
            y = 160 * u4 - 320 * u3 + 160 * u2 - 5
            z = P_u * math.sin(math.pi * v)
            vertices[i][j] = [x, y, z]

            P_u_deriv = -450 * u4 + 900 * u3 - 810 * u2 + 360 * u - 45
            xu = P_u_deriv * math.cos(math.pi * v)
            xv = -math.pi * P_u * math.sin(math.pi * v)
            yu = 640 * u3 - 960 * u2 + 320 * u
            yv = 0
            zu = P_u_deriv * math.sin(math.pi * v)
            zv = math.pi * P_u * math.cos(math.pi * v)

            nx = yu * zv - zu * yv
            ny = zu * xv - xu * zv
            nz = xu * yv - yu * xv

            length = math.sqrt(nx ** 2 + ny ** 2 + nz ** 2)
            if length > 0:
                nx, ny, nz = nx / length, ny / length, nz / length

            if u > 0.5:
                nx, ny, nz = -nx, -ny, -nz

            normals[i][j] = [nx, ny, nz]

            tex_coords[i][j] = [tex_u, tex_v]


def startup():
    global texture_ids
    compute_egg()
    update_viewport(None, 400, 400)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glEnable(GL_DEPTH_TEST)

    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glLightfv(GL_LIGHT0, GL_POSITION, [0.0, 0.0, 10.0, 1.0])
    glLightfv(GL_LIGHT0, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])
    glMaterialfv(GL_FRONT, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])

    glEnable(GL_TEXTURE_2D)

    texture_ids = glGenTextures(len(TEXTURE_FILES))

    if isinstance(texture_ids, int):
        texture_ids = [texture_ids]


    loaded_count = 0
    for i, filename in enumerate(TEXTURE_FILES):
        try:
            image = Image.open(filename)
        except IOError:
            print(f"OSTRZEŻENIE: Nie znaleziono pliku '{filename}'.")
            continue

        image = image.transpose(Image.FLIP_TOP_BOTTOM)
        img_data = image.convert("RGB").tobytes()

        current_id = texture_ids[i]

        glBindTexture(GL_TEXTURE_2D, current_id)
        glTexImage2D(
            GL_TEXTURE_2D, 0, GL_RGB, image.width, image.height,
            0, GL_RGB, GL_UNSIGNED_BYTE, img_data
        )

        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
        loaded_count += 1

    print(f"Załadowano {loaded_count} tekstur. Naciśnij 'T' aby zmieniać.")


def render(time):
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    gluLookAt(0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0)

    glRotatef(theta, 1.0, 0.0, 0.0)
    glRotatef(phi, 0.0, 1.0, 0.0)

    if len(texture_ids) > 0:
        idx = current_texture_index % len(texture_ids)
        glBindTexture(GL_TEXTURE_2D, texture_ids[idx])

    glColor3f(1.0, 1.0, 1.0)

    for i in range(N_EGG - 1):
        glBegin(GL_TRIANGLES)
        for j in range(N_EGG - 1):
            glNormal3fv(normals[i][j]);
            glTexCoord2fv(tex_coords[i][j]);
            glVertex3fv(vertices[i][j])
            glNormal3fv(normals[i + 1][j]);
            glTexCoord2fv(tex_coords[i + 1][j]);
            glVertex3fv(vertices[i + 1][j])
            glNormal3fv(normals[i][j + 1]);
            glTexCoord2fv(tex_coords[i][j + 1]);
            glVertex3fv(vertices[i][j + 1])

            glNormal3fv(normals[i][j + 1]);
            glTexCoord2fv(tex_coords[i][j + 1]);
            glVertex3fv(vertices[i][j + 1])
            glNormal3fv(normals[i + 1][j]);
            glTexCoord2fv(tex_coords[i + 1][j]);
            glVertex3fv(vertices[i + 1][j])
            glNormal3fv(normals[i + 1][j + 1]);
            glTexCoord2fv(tex_coords[i + 1][j + 1]);
            glVertex3fv(vertices[i + 1][j + 1])
        glEnd()

    glFlush()


def update_viewport(window, width, height):
    if height == 0: height = 1
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(70, width / height, 0.1, 300.0)
    glViewport(0, 0, width, height)
    glMatrixMode(GL_MODELVIEW)


def mouse_callback(window, xpos, ypos):
    global theta, phi, mouse_x_old, mouse_y_old
    if left_mouse_down:
        phi += (xpos - mouse_x_old) * 0.5
        theta += (ypos - mouse_y_old) * 0.5
    mouse_x_old = xpos
    mouse_y_old = ypos


def mouse_btn_callback(window, btn, action, mods):
    global left_mouse_down
    if btn == GLFW_MOUSE_BUTTON_LEFT:
        left_mouse_down = (action == GLFW_PRESS)


def key_callback(window, key, scancode, action, mods):
    global current_texture_index

    if action == GLFW_PRESS:
        if key == GLFW_KEY_ESCAPE:
            glfwSetWindowShouldClose(window, GLFW_TRUE)

        if key == GLFW_KEY_T:
            current_texture_index += 1
            # --- POPRAWKA BŁĘDU TEŻ TUTAJ ---
            if len(texture_ids) > 0:
                actual_idx = current_texture_index % len(texture_ids)
                print(f"Tekstura: {TEXTURE_FILES[actual_idx]}")


def main():
    if not glfwInit(): sys.exit(-1)
    window = glfwCreateWindow(600, 600, "Zadanie 5 - Fix", None, None)
    if not window: glfwTerminate(); sys.exit(-1)

    glfwMakeContextCurrent(window)
    glfwSetFramebufferSizeCallback(window, update_viewport)
    glfwSetCursorPosCallback(window, mouse_callback)
    glfwSetMouseButtonCallback(window, mouse_btn_callback)
    glfwSetKeyCallback(window, key_callback)

    startup()

    while not glfwWindowShouldClose(window):
        render(glfwGetTime())
        glfwSwapBuffers(window)
        glfwPollEvents()
    glfwTerminate()


if __name__ == '__main__':
    main()