#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define POWTORZENIA 10 // Ile razy powtarzamy

// Funkcja generująca losowe liczby zmiennoprzecinkowe (float) w przedziale [0, 1000]
// dla tablic a i b o rozmiarze n
void generuj_tablice(float* a, float* b, int n) {
    for (int i = 0; i < n; i++) {
        a[i] = (float)(rand()) / (float)(RAND_MAX) * 1000.0f;
        b[i] = (float)(rand()) / (float)(RAND_MAX) * 1000.0f;
    }
}

// Funkcja obliczająca czas trwania operacji w milisekundach
double oblicz_czas(struct timespec* start, struct timespec* end) {
    double czas = (end->tv_sec - start->tv_sec) * 1000.0;  // sekundy na milisekundy
    czas += (end->tv_nsec - start->tv_nsec) / 1000000.0;   // nanosekundy na milisekundy
    return czas;
}

// Funkcja dodawanie ze wstawkami w SISD
double dodawanie_asm_sisd(float* a, float* b, float* wynik, int n) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    float r;
    for (int i = 0; i < n; i++) {
        //Wstawka
        asm (
            "flds %1\n"  
            "fadds %2\n" 
            "fstps %0\n" 
            : "=m"(r)    
            : "m"(a[i]), "m"(b[i]) 
        );
        wynik[i] = r;  
    }
    clock_gettime(CLOCK_MONOTONIC, &end);  
    return oblicz_czas(&start, &end);      //Zwracamy czas
}

// Funkcja odejmowania ze wstawkami w SISD

double odejmowanie_asm_sisd(float* a, float* b, float* wynik, int n) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start); 
    float r;
    for (int i = 0; i < n; i++) {
        //Wstawka
        asm (
            "flds %1\n"  
            "fsubs %2\n" 
            "fstps %0\n" 
            : "=m"(r)    
            : "m"(a[i]), "m"(b[i]) 
        );
        wynik[i] = r;  
    }
    clock_gettime(CLOCK_MONOTONIC, &end);  
    return oblicz_czas(&start, &end);      //Zwracamy czas
}

// Funkcja mnożenie ze wstawkami w SISD

double mnozenie_asm_sisd(float* a, float* b, float* wynik, int n) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start); 
    float r;
    for (int i = 0; i < n; i++) {
        //Wstawka
        asm (
            "flds %1\n"  
            "fmuls %2\n" 
            "fstps %0\n"
            : "=m"(r)    
            : "m"(a[i]), "m"(b[i]) 
        );
        wynik[i] = r;  
    }
    clock_gettime(CLOCK_MONOTONIC, &end);  
    return oblicz_czas(&start, &end);      
}

// Funkcja dzielenia ze wstawkami w SISD

double dzielenie_asm_sisd(float* a, float* b, float* wynik, int n) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    float r;
    for (int i = 0; i < n; i++) {
        //Wstawka
        asm (
            "flds %1\n"  
            "fdivs %2\n" 
            "fstps %0\n" 
            : "=m"(r)    
            : "m"(a[i]), "m"(b[i]) 
        );
        wynik[i] = r;  
    }
    clock_gettime(CLOCK_MONOTONIC, &end);  
    return oblicz_czas(&start, &end);      
}

int main() {
    srand((unsigned)time(NULL));  // Inicjalizacja generatora liczb losowych

    int rozmiary[] = {2048, 4096, 8192};  //Ilości liczb
    int liczba_testow = 3; // Liczba testów bo dla każdej ilości liczb

    FILE* plik = fopen("wynikiSISD.txt", "w"); // Otwarcie pliku do zapisania wyników
    if (!plik) {
        perror("Nie mozna otworzyc pliku");
        return EXIT_FAILURE;
    }

    // Pętla po ilości liczb
    for (int i = 0; i < liczba_testow; i++) {
        int n = rozmiary[i];           
        int rzeczywista_ilosc = n / 2; // Ilość elementów w każdej z tablic a, b i wynik bo n to ogólna ilość liczb

        // Alokacja pamięci dla tablic a, b i wynik w zależności od ilości potrzebnej pamięci
        float* a = malloc(rzeczywista_ilosc * sizeof(float));
        float* b = malloc(rzeczywista_ilosc * sizeof(float));
        float* wynik = malloc(rzeczywista_ilosc * sizeof(float));

        if (!a || !b || !wynik) {
            perror("Blad alokacji pamieci");
            return EXIT_FAILURE;
        }

        double suma[4] = {0.0};

        // Wykonujemy testy dla róznych liczb żeby było wiarygodniejsze
        for (int p = 0; p < POWTORZENIA; p++) {
            generuj_tablice(a, b, rzeczywista_ilosc);  // Losowanie liczb
            suma[0] += dodawanie_asm_sisd(a, b, wynik, rzeczywista_ilosc);
            suma[1] += odejmowanie_asm_sisd(a, b, wynik, rzeczywista_ilosc);
            suma[2] += mnozenie_asm_sisd(a, b, wynik, rzeczywista_ilosc);
            suma[3] += dzielenie_asm_sisd(a, b, wynik, rzeczywista_ilosc);
        }

        // Zapis wyników do pliku
        fprintf(plik, "Typ obliczen: SISD\n");
        fprintf(plik, "Liczba liczb: %d\n", n);
        fprintf(plik, "+ %f ms\n", suma[0] / POWTORZENIA);
        fprintf(plik, "- %f ms\n", suma[1] / POWTORZENIA);
        fprintf(plik, "* %f ms\n", suma[2] / POWTORZENIA);
        fprintf(plik, "/ %f ms\n\n", suma[3] / POWTORZENIA);

        // Zapis wyników na ekranie
        printf("Typ obliczen: SISD\n");
        printf("Liczba liczb : %d\n", n);
        printf("+ %f ms\n", suma[0] / POWTORZENIA);
        printf("- %f ms\n", suma[1] / POWTORZENIA);
        printf("* %f ms\n", suma[2] / POWTORZENIA);
        printf("/ %f ms\n\n", suma[3] / POWTORZENIA);

        // Zwolnienie pamięci
        free(a);
        free(b);
        free(wynik);
    }

    // Zamknięcie pliku
    fclose(plik);
    return 0;
}
