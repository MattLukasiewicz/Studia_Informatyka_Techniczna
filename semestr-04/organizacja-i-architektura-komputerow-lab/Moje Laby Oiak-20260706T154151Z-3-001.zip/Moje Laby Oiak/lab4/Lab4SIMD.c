#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <immintrin.h> 

// Makrodefinicje
#define ROZMIAR_WEKTORA 4      // Rozmiar wektora 
#define POWTORZENIA 10         // Liczba powtórzeń testów dla obliczeń

// Struktura reprezentująca wektor SIMD
typedef struct {
    __m128 dane;  // Zmienna typu __m128 przechowuje 4 liczby zmiennoprzecinkowe (float) w jednym wektorze
} WektorSIMD;

// Funkcja do generowania danych do tablic wektorów
void generuj_wektory(WektorSIMD* wektory_a, WektorSIMD* wektory_b, int liczba_wektorow) {
    for (int i = 0; i < liczba_wektorow; i++) {
        float tab_a[ROZMIAR_WEKTORA], tab_b[ROZMIAR_WEKTORA];
        
        // Generowanie danych losowych dla tablic a[] i b[]
        for (int j = 0; j < ROZMIAR_WEKTORA; j++) {
            tab_a[j] = ((float)rand() / RAND_MAX) * 1000.0f;          
            tab_b[j] = ((float)rand() / RAND_MAX) * 1000.0f + 1.0f; 
        }
        
        // Wczytanie danych do wektorów SIMD
        wektory_a[i].dane = _mm_loadu_ps(tab_a);  // Wczytuje tablicę a[] do wektora SIMD
        wektory_b[i].dane = _mm_loadu_ps(tab_b);  // Wczytuje tablicę b[] do wektora SIMD
    }
}

// Funkcja do dodawania wektorów SIMD 
double dodawanie_asm_simd(WektorSIMD* wektory_a, WektorSIMD* wektory_b, WektorSIMD* wektory_wynik, int liczba_wektorow) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start); 

    // Pętla wykonująca dodawanie dla każdego wektora
    for (int i = 0; i < liczba_wektorow; i++) {
        __m128 a = wektory_a[i].dane;  // Ładowanie wektora a
        __m128 b = wektory_b[i].dane;  // Ładowanie wektora b

        // Operacja ASM do dodawania 
        asm(
            "movaps %1, %%xmm0;"         // Załadowanie a do rejestru xmm0
            "movaps %2, %%xmm1;"         // Załadowanie b do rejestru xmm1
            "addps %%xmm1, %%xmm0;"      // Dodanie xmm1 do xmm0
            "movaps %%xmm0, %0;"         // Zapisanie wyniku do wektora wynik
            : "=m"(wektory_wynik[i].dane) // Wartość wyjściowa
            : "m"(a), "m"(b)             // Wartości wejściowe
            : "%xmm0", "%xmm1"           // Zmieniane rejestry
        );
    }

    clock_gettime(CLOCK_MONOTONIC, &end); 
    return (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_nsec - start.tv_nsec) / 1e6;  
}

// Funkcja do odejmowania wektorów SIMD 
double odejmowanie_asm_simd(WektorSIMD* wektory_a, WektorSIMD* wektory_b, WektorSIMD* wektory_wynik, int liczba_wektorow) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);  

    // Pętla wykonująca odejmowanie dla każdego wektora
    for (int i = 0; i < liczba_wektorow; i++) {
        __m128 a = wektory_a[i].dane;  // Ładowanie wektora a
        __m128 b = wektory_b[i].dane;  // Ładowanie wektora b

        // Operacja ASM do odejmowania 
        asm(
            "movaps %1, %%xmm0;"         // Załadowanie a do rejestru xmm0
            "movaps %2, %%xmm1;"         // Załadowanie b do rejestru xmm1
            "subps %%xmm1, %%xmm0;"      // Odejmowanie xmm1 od xmm0
            "movaps %%xmm0, %0;"         // Zapisanie wyniku do wektora wynik
            : "=m"(wektory_wynik[i].dane) // Wartość wyjściowa
            : "m"(a), "m"(b)             // Wartości wejściowe
            : "%xmm0", "%xmm1"           // Zmieniane rejestry
        );
    }

    clock_gettime(CLOCK_MONOTONIC, &end);  
    return (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_nsec - start.tv_nsec) / 1e6;
}

// Funkcja do mnożenia wektorów SIMD 
double mnozenie_asm_simd(WektorSIMD* wektory_a, WektorSIMD* wektory_b, WektorSIMD* wektory_wynik, int liczba_wektorow) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);  

    // Pętla wykonująca mnożenie 
    for (int i = 0; i < liczba_wektorow; i++) {
        __m128 a = wektory_a[i].dane;  // Ładowanie wektora a
        __m128 b = wektory_b[i].dane;  // Ładowanie wektora b

        // Operacja ASM do mnożenia 
        asm(
            "movaps %1, %%xmm0;"         // Załadowanie a do rejestru xmm0
            "movaps %2, %%xmm1;"         // Załadowanie b do rejestru xmm1
            "mulps %%xmm1, %%xmm0;"      // Mnożenie xmm0 przez xmm1
            "movaps %%xmm0, %0;"         // Zapisanie wyniku do wektora wynik
            : "=m"(wektory_wynik[i].dane) // Wartość wyjściowa
            : "m"(a), "m"(b)             // Wartości wejściowe
            : "%xmm0", "%xmm1"           // Zmieniane rejestry
        );
    }

    clock_gettime(CLOCK_MONOTONIC, &end);  
    return (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_nsec - start.tv_nsec) / 1e6;  
}

// Funkcja do dzielenia wektorów SIMD 
double dzielenie_asm_simd(WektorSIMD* wektory_a, WektorSIMD* wektory_b, WektorSIMD* wektory_wynik, int liczba_wektorow) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);  

    // Pętla wykonująca dzielenie dla każdego wektora
    for (int i = 0; i < liczba_wektorow; i++) {
        __m128 a = wektory_a[i].dane;  // Ładowanie wektora a
        __m128 b = wektory_b[i].dane;  // Ładowanie wektora b

        // Operacja ASM do dzielenia -
        asm(
            "movaps %1, %%xmm0;"         // Załadowanie a do rejestru xmm0
            "movaps %2, %%xmm1;"         // Załadowanie b do rejestru xmm1
            "divps %%xmm1, %%xmm0;"      // Dzielenie xmm0 przez xmm1
            "movaps %%xmm0, %0;"         // Zapisanie wyniku do wektora wynik
            : "=m"(wektory_wynik[i].dane) // Wartość wyjściowa
            : "m"(a), "m"(b)             // Wartości wejściowe
            : "%xmm0", "%xmm1"           // Zmieniane rejestry
        );
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    return (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_nsec - start.tv_nsec) / 1e6;  
}

// Funkcja główna
int main() {
    srand((unsigned)time(NULL));

    int rozmiary[] = {2048, 4096, 8192};  //Ile liczb
    int liczba_testow = 3;

    // Otwarcie pliku do zapisu wyników
    FILE* plik = fopen("wynikiSIMD.txt", "w");
    if (!plik) {
        perror("Nie mozna otworzyc pliku");
        return EXIT_FAILURE;  // Zakończenie programu w przypadku błędu
    }

    
    for (int test = 0; test < liczba_testow; test++) {
        int liczba_elementow = rozmiary[test];
        int podziel_na_dwa = liczba_elementow / 2;  // Podział przez 2, aby rozdzielić dane na 2 tablice
        int liczba_wektorow = podziel_na_dwa / ROZMIAR_WEKTORA;  // Obliczenie liczby wektorów

        // Tablice wektorów SIMD
        WektorSIMD wektory_a[liczba_wektorow];
        WektorSIMD wektory_b[liczba_wektorow];
        WektorSIMD wektory_wynik[liczba_wektorow];

        double suma_czasow[4] = {0.0, 0.0, 0.0, 0.0};  // Zmienna do sumowania czasów operacji

        // Pętla po powtórzeniach
        for (int powtorzenie = 0; powtorzenie < POWTORZENIA; powtorzenie++) {
            generuj_wektory(wektory_a, wektory_b, liczba_wektorow);  // Generowanie danych wejściowych

            // Obliczenia SIMD
            suma_czasow[0] += dodawanie_asm_simd(wektory_a, wektory_b, wektory_wynik, liczba_wektorow);
            suma_czasow[1] += odejmowanie_asm_simd(wektory_a, wektory_b, wektory_wynik, liczba_wektorow);
            suma_czasow[2] += mnozenie_asm_simd(wektory_a, wektory_b, wektory_wynik, liczba_wektorow);
            suma_czasow[3] += dzielenie_asm_simd(wektory_a, wektory_b, wektory_wynik, liczba_wektorow);
        }

        // Zapis wyników do pliku
        fprintf(plik, "Typ obliczen: SIMD\n");
        fprintf(plik, "Liczba liczb: %d\n", liczba_elementow);
        fprintf(plik, "+ %.f ms\n", suma_czasow[0] / POWTORZENIA);
        fprintf(plik, "- %.f ms\n", suma_czasow[1] / POWTORZENIA);
        fprintf(plik, "* %.f ms\n", suma_czasow[2] / POWTORZENIA);
        fprintf(plik, "/ %.f ms\n\n", suma_czasow[3] / POWTORZENIA);

        // Wyświetlanie wyników na ekranie
        printf("Typ obliczen: SIMD\n");
        printf("Liczba liczb: %d\n", liczba_elementow);
        printf("+ %f ms\n", suma_czasow[0] / POWTORZENIA);
        printf("- %f ms\n", suma_czasow[1] / POWTORZENIA);
        printf("* %f ms\n", suma_czasow[2] / POWTORZENIA);
        printf("/ %f ms\n\n", suma_czasow[3] / POWTORZENIA);
    }

    fclose(plik);  // Zamknięcie pliku
    return 0;      // Zakończenie programu
}

