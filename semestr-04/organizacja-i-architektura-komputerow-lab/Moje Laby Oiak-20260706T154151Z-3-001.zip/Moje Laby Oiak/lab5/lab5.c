#include <stdio.h>
#include <time.h>
#include <stdlib.h>
int sortowanie(int tab[], int rozmiar){
	for(int i=0;i<rozmiar-1;i++){
		for(int j=0;j<rozmiar-1-i;j++)
			if(tab[j]>tab[j+1]){
				int a=tab[j];
				tab[j]=tab[j+1];
				tab[j+1] = a;
			}
	}
	
}
void generuj_tablice(int* tablica, int rozmiar){
	for(int i=0;i<rozmiar;i++){
		tablica[i]=(rand()%1000)+1;
	
	}

}


double oblicz_czas(struct timespec start,struct timespec end){
	double sec = end.tv_sec - start.tv_sec;
	double nano = end.tv_nsec - start.tv_nsec;
	return sec*1000.0 +nano/1e6;

}

int euklides(int a,int b){
	while(b!=0){
		int r = a%b;
		a=b;
		b=r;
	}
	return a;

}
int euklides_asm(int a, int b) {
    int wynik;
    asm __volatile__(
        "1:\n\t"
        "movl %2, %%eax\n\t"         // Załaduj a do EAX
        "xorl %%edx, %%edx\n\t"        // Wyzeruj EDX
        "divl %1\n\t"                // Dziel EAX przez b (wynik w EAX, reszta w EDX)
        "movl %1, %2\n\t"          // a = b
        "movl %%edx, %1\n\t"         // b = reszta
        "test %1, %1\n\t"          // Sprawdź, czy b jest różne od 0
        "jnz 1b\n\t"                   // Jeśli b != 0, wróć do 1
        "movl %2, %0\n\t"      // Wynik = a
        : [wynik] "=r" (wynik), [a] "+r" (a), [b] "+r" (b)
        :
        : "eax", "edx"
    );
    return wynik;
}





int main(){
	struct timespec t1,t2;
	srand((unsigned)time(NULL));
	//int tablica[20] = {10, 3, 5, 7, 2, 8, 1, 4, 6, 9, 12, 11, 15, 14, 13, 17, 16, 18, 20, 19};
	int rozmiar = 20;
	int tablica[rozmiar];
	generuj_tablice(tablica,rozmiar);
	sortowanie(tablica,rozmiar);
	for(int i=0; i<20;i++){
		printf("%d\n",tablica[i]);

	};
	
	
	
	
	int a=1071,b=462;
	clock_gettime(CLOCK_MONOTONIC,&t1);
	//clock_t start = clock();
	int wynik_c = euklides(a,b);
	//clock_t  end = clock();
	clock_gettime(CLOCK_MONOTONIC,&t2);
	printf("Wynik NWD = %d , czas = %f ms\n",wynik_c,oblicz_czas(t1,t2));
	//start = clock();
	clock_gettime(CLOCK_MONOTONIC,&t1);
	int wynik_asm = euklides_asm(a,b);
	//end = clock();
	//(double)(end-start)/CLOCKS_PER_SEC*1000
	clock_gettime(CLOCK_MONOTONIC,&t2);
	printf("Wynik NWD asm = %d , czas = %f ms\n",wynik_asm,oblicz_czas(t1,t2));

	//printf("%d\n", euklides(20,10)); 
	



	return 0;
}
