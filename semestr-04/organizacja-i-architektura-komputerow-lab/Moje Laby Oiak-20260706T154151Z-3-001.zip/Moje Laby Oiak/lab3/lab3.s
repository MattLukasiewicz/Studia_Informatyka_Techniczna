.global _start

.section .data
zero:         .float 0.0
minus_one:    .float -1.0
two:          .float 2.0

single_precision: .word 0x007F
double_precision: .word 0x017F

round_nearest: .word 0x037F   # Domyślnie: nearest
round_down:    .word 0x077F   # RC = 01
round_up:      .word 0x0B7F   # RC = 10
round_zero:    .word 0x0F7F   # RC = 11

wynik:        .float 0.0

.section .text

_start:
    finit                          # Inicjalizacja FPU

    Wyjatki:
    #0
    fldz
    
    #-0
    fldz                           # 0.0 → ST(0)
    fmuls minus_one          # ST(0) = 0.0 * -1.0 → -0.0
    
    #+Inf
    fld1
    fdivs zero
    
    #-Inf
    flds minus_one
    fdivs zero
    
    #NaN
    fldz
    fdivs zero
    
    #Czyszczenie stosu
    ffree %st(0)
    fstp %st(0)
    
    finit
    
    Precyzja:
    fldpi
    flds minus_one
    fadd %st(1),%st(0)
    
    fldcw single_precision
    
    fldpi
    flds minus_one
    fadd %st(1),%st(0)
    
    fldcw double_precision
    
    fldpi
    flds minus_one
    fadd %st(1),%st(0)
    
    Zaokrąglij:
    finit                 # Zresetuj FPU, ustaw domyślny tryb zaokrąglania (round to nearest)

    # --- Round to nearest ---
    fldcw round_nearest   # Załaduj tryb "round to nearest"
    fldpi                 # Załaduj pi
    fld1                  # Załaduj 1.0
    fsub %st(1), %st(0)   # pi - 1
    # Wynik będzie zaokrąglony do najbliższej liczby

    nop                   # Pauza (poczekaj na sprawdzenie w GDB)

    # --- Round down (toward -∞) ---
    fldcw round_down      # Załaduj tryb "round down"
    fldpi
    fld1
    fsub %st(1), %st(0)
    # Wynik będzie zaokrąglony w dół

    nop                   # Pauza (poczekaj na sprawdzenie w GDB)

    # --- Round up (toward +∞) ---
    fldcw round_up        # Załaduj tryb "round up"
    fldpi
    fld1
    fsub %st(1), %st(0)
    # Wynik będzie zaokrąglony w górę

    nop                   # Pauza (poczekaj na sprawdzenie w GDB)

    # --- Truncate (toward 0) ---
    fldcw round_zero      # Załaduj tryb "truncate"
    fldpi
    fld1
    fsub %st(1), %st(0)
    # Wynik będzie obcięty do zera (bez części ułamkowej)

    nop                   # Pauza (poczekaj na sprawdzenie w GDB)
    
    

    # === Exit syscall ===
    mov $1, %eax
    xor %ebx, %ebx
    int $0x80
