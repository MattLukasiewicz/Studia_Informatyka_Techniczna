.global _start

.section .data
liczba1:
    .long 0x10304008, 0x701100FF, 0x45100020, 0x10304008  # 4 części 32-bitowe od najstarszej do najmłodszej
liczba2:
    .long 0xF040500C, 0x00220026, 0x321000CB, 0xF040500C

.section .text

_start:
    clc          # Zerujemy flagę przeniesienia przed pierwszym dodawaniem
    mov $3, %ecx # Licznik iteracji (ostatni indeks tablicy)

dodawanie:
    mov $liczba1, %ebx
    mov (%ebx, %ecx, 4), %eax  # Pobieramy część liczby1

    mov $liczba2, %ebx
    mov (%ebx, %ecx, 4), %edx  # Pobieramy część liczby2

    adc %edx, %eax  # Dodajemy liczby + ewentualne przeniesienie
    push %eax       # Odkładamy wynik na stos

    dec %ecx        # Zmniejszamy licznik iteracji
    jns dodawanie   # Powtarzamy dla kolejnej części liczby, jeśli nie doszliśmy do liczby ujemnej

    jnc exit        # Jeśli po ostatnim dodaniu nie było przeniesienia, kończymy
    push $1         # Jeśli było przeniesienie, dodajemy 1 na stos (najstarsza część wyniku)

exit:
    mov $1, %eax    # syscall: exit
    xor %ebx, %ebx  # kod wyjścia 0
    int $0x80       # wywołanie systemowe
