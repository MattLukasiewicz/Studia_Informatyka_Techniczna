.global _start

.section .data
liczba1:
    .long  0x10304008, 0x45100020, 0x08570030, 0x10304008  # 4 części 32-bitowe
liczba2:
    .long 0xF040500C, 0x321000CB, 0x04520031, 0xF040500C
//liczba1:
//	.long 0x02, 0x05, 0x03, 0x01
//liczba2:
//	.long 0x03, 0x04, 0x02, 0x02
.section .text

_start:
    clc          # Zerujemy flagę przeniesienia przed pierwszym odejmowaniem
    mov $3, %ecx # Licznik iteracji (ostatni indeks tablicy)

odejmowanie:
    mov $liczba1, %ebx
    mov (%ebx, %ecx, 4), %eax  # Pobieramy część liczby1

    mov $liczba2, %ebx
    mov (%ebx, %ecx, 4), %edx  # Pobieramy część liczby2

    sbb %edx, %eax  # Odejmujemy liczby + ewentualne pożyczone przeniesienie
    push %eax       # Odkładamy wynik na stos

    dec %ecx        # Zmniejszamy licznik iteracji
    jns odejmowanie # Powtarzamy dla kolejnej części liczby, jeśli nie doszliśmy do końca

    jnc exit        # Jeśli po ostatnim odejmowaniu nie było pożyczki, kończymy
    push $-1        # Jeśli była pożyczka, dodajemy -1 na stos (najstarsza część wyniku)

exit:
    mov $1, %eax    # syscall: exit
    xor %ebx, %ebx  # kod wyjścia 0
    int $0x80       # wywołanie systemowe
