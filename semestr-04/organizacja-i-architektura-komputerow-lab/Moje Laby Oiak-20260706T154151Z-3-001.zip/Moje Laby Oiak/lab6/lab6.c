#include <stdio.h>

// Macierz 3x3 (ostatni element to padding, by dopasować do 4-elementowych wektorów SIMD)
__attribute__((aligned(16))) float m[3][4] = {
    {1.0f, 2.0f, 3.0f, 0.0f},  // wiersz 1: a11, a12, a13, padding
    {4.0f, 5.0f, 6.0f, 0.0f},  // wiersz 2: a21, a22, a23, padding
    {7.0f, 8.0f, 9.0f, 0.0f}   // wiersz 3: a31, a32, a33, padding
};

// Funkcja obliczająca wyznacznik macierzy 3x3 przy użyciu SSE i SHUFPS
float determinant3x3(float mat[3][4]) {
    float result;

    asm volatile (
        // Wczytanie pierwszego wiersza macierzy do xmm0: [a11, a12, a13, 0.0]
        "movaps (%1), %%xmm0\n\t"
        // Wczytanie drugiego wiersza do xmm1: [a21, a22, a23, 0.0]
        "movaps 16(%1), %%xmm1\n\t"
        // Wczytanie trzeciego wiersza do xmm2: [a31, a32, a33, 0.0]
        "movaps 32(%1), %%xmm2\n\t"

        // -----------------------------------------
        // Obliczamy minor M11 = a22*a33 - a23*a32
        // -----------------------------------------

        "movaps %%xmm1, %%xmm3\n\t" // Kopiujemy xmm1 do xmm3
        "movaps %%xmm2, %%xmm4\n\t" // Kopiujemy xmm2 do xmm4

        // Przestawiamy: xmm3 = [a22, a23, ?, ?]
        "shufps $0x55, %%xmm3, %%xmm3\n\t"
        // Przestawiamy: xmm4 = [a32, a33, ?, ?]
        "shufps $0xAA, %%xmm4, %%xmm4\n\t"

        // Kopiujemy do xmm5 i xmm6
        "movaps %%xmm3, %%xmm5\n\t" // xmm5 = [a22, a23, ?, ?]
        "movaps %%xmm4, %%xmm6\n\t" // xmm6 = [a32, a33, ?, ?]

        // Wyciągamy a23 i a33 z odpowiednich miejsc
        "shufps $0x01, %%xmm5, %%xmm5\n\t" // xmm5 = [a23, ?, ?, ?]
        "shufps $0x10, %%xmm6, %%xmm6\n\t" // xmm6 = [a33, ?, ?, ?]

        // Mnożenia skalarnie: a22 * a33
        "mulss %%xmm3, %%xmm4\n\t"
        // a23 * a32
        "mulss %%xmm5, %%xmm6\n\t"

        // Różnica: M11 = a22*a33 - a23*a32
        "subss %%xmm6, %%xmm4\n\t"

        // Załaduj a11 i pomnóż przez M11
        "movss %%xmm0, %%xmm7\n\t"
        "mulss %%xmm4, %%xmm7\n\t"

        // -----------------------------------------
        // Obliczamy minor M12 = a21*a33 - a23*a31
        // -----------------------------------------

        // Znów kopiujemy potrzebne wiersze
        "movaps %%xmm1, %%xmm3\n\t"
        "movaps %%xmm2, %%xmm4\n\t"

        // a21
        "shufps $0x00, %%xmm3, %%xmm3\n\t"
        // a33
        "shufps $0xAA, %%xmm4, %%xmm4\n\t"
        "shufps $0x10, %%xmm4, %%xmm5\n\t"

        // a31
        "shufps $0x10, %%xmm2, %%xmm6\n\t"
        // a23
        "shufps $0x20, %%xmm1, %%xmm4\n\t"

        // Obliczamy: a21*a33
        "mulss %%xmm3, %%xmm5\n\t"
        // Obliczamy: a23*a31
        "mulss %%xmm4, %%xmm6\n\t"

        // M12 = a21*a33 - a23*a31
        "subss %%xmm6, %%xmm5\n\t"

        // Ładujemy a12 i mnożymy przez M12
        "movss 4(%1), %%xmm6\n\t"
        "mulss %%xmm5, %%xmm6\n\t"

        // Odejmuje (- a12 * M12)
        "subss %%xmm6, %%xmm7\n\t"

        // -----------------------------------------
        // Obliczamy minor M13 = a21*a32 - a22*a31
        // -----------------------------------------

        // Znów kopiujemy wiersze
        "movaps %%xmm1, %%xmm3\n\t"
        "movaps %%xmm2, %%xmm4\n\t"

        // a21
        "shufps $0x00, %%xmm3, %%xmm3\n\t"
        // a32
        "shufps $0x55, %%xmm4, %%xmm4\n\t"
        // a21 * a32
        "mulss %%xmm3, %%xmm4\n\t"

        // a22
        "shufps $0x55, %%xmm1, %%xmm5\n\t"
        // a31
        "shufps $0x00, %%xmm2, %%xmm6\n\t"
        // a22 * a31
        "mulss %%xmm5, %%xmm6\n\t"

        // M13 = a21*a32 - a22*a31
        "subss %%xmm6, %%xmm4\n\t"

        // Załaduj a13
        "movss 8(%1), %%xmm6\n\t"
        // a13 * M13
        "mulss %%xmm4, %%xmm6\n\t"

        // Dodaj do wyznacznika
        "addss %%xmm6, %%xmm7\n\t"

        // Przenieś wynik do zmiennej result
        "movss %%xmm7, %0\n\t"

        : "=m"(result)
        : "r"(mat)
        : "memory", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6", "xmm7"
    );

    return result;
}

int main() {
    float det = determinant3x3(m);
    printf("Wyznacznik macierzy 3x3 = %.2f\n", det);
    return 0;
}
