#include <stdio.h>
#include <xmmintrin.h>   // SSE intrinsics and types

// Funkcja pokazująca krok po kroku operacje wektorowe dla 2×2 det
static float det2_debug(const float *m) {
    // Bufory na wydrukowanie stanu rejestrów
    float a[4], b[4], c[4], d[4], e[4];

    // 1. Załaduj wektor [a, b, c, d]
    __m128 v0 = _mm_loadu_ps(m);
    _mm_storeu_ps(a, v0);
    printf("Step 1 (load): [ %f, %f, %f, %f ]\n", a[0], a[1], a[2], a[3]);

    // 2. Permutacja: v1 = [d, c, b, a]
    __m128 v1 = _mm_shuffle_ps(v0, v0, _MM_SHUFFLE(0,1,2,3)); // mask 0x1B
    _mm_storeu_ps(b, v1);
    printf("Step 2 (shuffle1): [ %f, %f, %f, %f ]\n", b[0], b[1], b[2], b[3]);

    // 3. Mnożenie wektorowe: v2[i] = v0[i] * v1[i]
    __m128 v2 = _mm_mul_ps(v0, v1);
    _mm_storeu_ps(c, v2);
    printf("Step 3 (mul): [ %f, %f, %f, %f ]\n", c[0], c[1], c[2], c[3]);

    // 4. Druga permutacja: v3 = [b*c, a*d, d*a, c*b]
    __m128 v3 = _mm_shuffle_ps(v2, v2, _MM_SHUFFLE(2,3,0,1)); // mask 0xB1 reversed correctly // mask 0xB1
    _mm_storeu_ps(d, v3);
    printf("Step 4 (shuffle2): [ %f, %f, %f, %f ]\n", d[0], d[1], d[2], d[3]);

    // 5. Odejmowanie: v4 = v2 - v3 => [a*d-b*c, ...]
    __m128 v4 = _mm_sub_ps(v2, v3);
    _mm_storeu_ps(e, v4);
    printf("Step 5 (sub): [ %f, %f, %f, %f ]\n", e[0], e[1], e[2], e[3]);

    // Wynik to pierwszy element
    float det = e[0];
    printf("Result (det) = %f\n", det);
    return det;
}

int main() {
    // Przykładowa macierz 2×2: [3,5;7,2]
    float m2[4] = { 9.0f, 6.0f, 7.0f, 4.0f };
    det2_debug(m2);
    return 0;
}
