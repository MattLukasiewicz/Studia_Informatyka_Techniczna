#include <stdio.h>
#include <xmmintrin.h>
/*Maska*/
#define SHUF(x, y, z, w)  ((x) | ((y)<<2) | ((z)<<4) | ((w)<<6))

#define CALC(A, B, SH1, SH2, DST)                                   \
    do {                                                            \
        asm (                                       \
            "movaps    %1, %0             \n\t"                     \
            "movaps    %2, %%xmm7        \n\t"                     \
            "shufps    %3, %0, %0          \n\t"                     \
            "shufps    %4, %%xmm7, %%xmm7\n\t"                     \
	/*DST = A' * B'*/						\
            "mulps     %%xmm7, %0         \n\t"                     \
                                                                    \
            "movaps    %1, %%xmm6        \n\t"                     \
            "movaps    %2, %%xmm7        \n\t"                     \
            "shufps    %4, %%xmm6, %%xmm6\n\t"                     \
            "shufps    %3, %%xmm7, %%xmm7\n\t"                     \
								\
	/*xmm7 = A\" * B\"*/					\
            "mulps     %%xmm6, %%xmm7    \n\t"                     \
                                                                    \
	/* DST = (A'*B') - (A\"*B\")*/					\
            "subps     %%xmm7, %0         \n\t"                     \
            : "=&x" (DST)        /* (0) DST wynikowy rejestr   */     \
            : "x"  (A),         /* (1) A: wektor wejściowy    */     \
              "x"  (B),         /* (2) B: wektor wejściowy    */     \
              "i"  (SH1),       /* (3) imm8 SH1 dla shufps    */     \
              "i"  (SH2)        /* (4) imm8 SH2 dla shufps    */     \
            : "xmm6", "xmm7"     /* xmm6,xmm7 rejestry pomocnicze niszczymy je  */   \
        );                                                          \
    } while (0)

float sse_det4x4(const float* m) {
/*Ładujemy wiersze do rejesrtrów*/
    __m128 A = _mm_loadu_ps(&m[0]);
    __m128 B = _mm_loadu_ps(&m[4]);
    __m128 C = _mm_loadu_ps(&m[8]);
    __m128 D = _mm_loadu_ps(&m[12]);

    __m128 vecX, vecY, part;
	/* Wektor 1*/
    CALC(A, B, SHUF(0,2,0,1), SHUF(1,0,3,2), vecX);
	/* Wektor 2*/
    CALC(C, D, SHUF(2,1,1,0), SHUF(3,3,2,3), vecY);
	/* Wektor 1 razy wektor 2*/
    part = _mm_mul_ps(vecX, vecY);

	/* Wektor 3*/
    CALC(A, B, SHUF(2,3,0,0), SHUF(3,1,0,0), vecX);
	/* Wektor 4*/
    CALC(C, D, SHUF(0,0,0,0), SHUF(1,2,0,0), vecY);
	/* Wektor 3 razy wektor 4*/
    vecX = _mm_mul_ps(vecX, vecY);

	/* sumujemy części wektora part*/
    float sum[4];
    _mm_storeu_ps(sum, part);
    float result = sum[0] + sum[1] + sum[2] + sum[3];
	/* sumujemy części wektora vecx*/
    _mm_storeu_ps(sum, vecX);
    result += sum[0] + sum[1];

    return result;
}

int main(void) {

    float mat[16] = {
        2.0f,  6.0f,  5.0f,  0.0f,
        9.0f,  6.0f,  3.0f,  0.0f,
        4.0f,  2.0f,  1.0f,  2.0f,
        4.0f,  3.0f,  1.0f,  3.0f
    };

    float wynik = sse_det4x4(mat);
    printf("Wyznacznik macierzy: %.4f\n", wynik);
    return 0;
}
