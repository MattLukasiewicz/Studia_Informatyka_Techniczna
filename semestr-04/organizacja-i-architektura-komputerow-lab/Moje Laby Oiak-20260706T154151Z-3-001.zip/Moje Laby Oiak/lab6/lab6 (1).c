#include <stdio.h>
#include <xmmintrin.h>   // SSE intrinsics

// Drukuj __m128 jako cztery floats
void print_m128(const char *label, __m128 v) {
    float f[4];
    _mm_storeu_ps(f, v);
    printf("%s = [%.2f, %.2f, %.2f, %.2f]\n",
           label, f[0], f[1], f[2], f[3]);
}

// Debugująca wersja obliczania det 4×4
float debug_det4x4(const float M[4][4]) {
    // 1) Załaduj wiersze A,B,C,D
    __m128 rowA = _mm_loadu_ps(&M[0][0]);
    __m128 rowB = _mm_loadu_ps(&M[1][0]);
    __m128 rowC = _mm_loadu_ps(&M[2][0]);
    __m128 rowD = _mm_loadu_ps(&M[3][0]);

    print_m128("rowA", rowA);
    print_m128("rowB", rowB);
    print_m128("rowC", rowC);
    print_m128("rowD", rowD);

    // 2) x0..x3 = (a0b1 - a1b0, a2b0 - a0b2, a0b3 - a3b0, a1b2 - a2b1)
    __m128 x0123 = _mm_sub_ps(
        _mm_mul_ps(_mm_shuffle_ps(rowA,rowA,_MM_SHUFFLE(1,0,2,0)),
                   _mm_shuffle_ps(rowB,rowB,_MM_SHUFFLE(2,3,0,1))),
        _mm_mul_ps(_mm_shuffle_ps(rowA,rowA,_MM_SHUFFLE(2,3,0,1)),
                   _mm_shuffle_ps(rowB,rowB,_MM_SHUFFLE(1,0,2,0)))
    );
    print_m128("x0123", x0123);

    // 3) y0..y3 = (c2d3-c3d2, c1d3-c3d1, c1d2-c2d1, c0d3-c3d0)
    __m128 y0123 = _mm_sub_ps(
        _mm_mul_ps(_mm_shuffle_ps(rowC,rowC,_MM_SHUFFLE(0,1,1,2)),
                   _mm_shuffle_ps(rowD,rowD,_MM_SHUFFLE(3,2,3,3))),
        _mm_mul_ps(_mm_shuffle_ps(rowC,rowC,_MM_SHUFFLE(3,2,3,3)),
                   _mm_shuffle_ps(rowD,rowD,_MM_SHUFFLE(0,1,1,2)))
    );
    print_m128("y0123", y0123);

    // 4) Pierwsze 4 iloczyny
    __m128 prod0123 = _mm_mul_ps(x0123, y0123);
    print_m128("prod0123", prod0123);

    // 5) Oblicz skalarnie x4,x5,y4,y5
    float a0=M[0][0], a1=M[0][1], a2=M[0][2], a3=M[0][3];
    float b0=M[1][0], b1=M[1][1], b2=M[1][2], b3=M[1][3];
    float c0=M[2][0], c1=M[2][1], c2=M[2][2], c3=M[2][3];
    float d0=M[3][0], d1=M[3][1], d2=M[3][2], d3=M[3][3];

    float x4 = a2*b3 - a3*b2;
    float x5 = a3*b1 - a1*b3;
    float y4 = c0*d1 - c1*d0;
    float y5 = c0*d2 - c2*d0;
    printf("x4=%.2f, x5=%.2f, y4=%.2f, y5=%.2f\n", x4, x5, y4, y5);

    // 6) Umieść je w wektorach [x4, x5, 0, 0] i [y4, y5, 0, 0]
    __m128 extraX = _mm_setr_ps(x4, x5, 0.0f, 0.0f);
    __m128 extraY = _mm_setr_ps(y4, y5, 0.0f, 0.0f);
    print_m128("extraX", extraX);
    print_m128("extraY", extraY);

    __m128 prod45 = _mm_mul_ps(extraX, extraY);
    print_m128("prod45", prod45);

    // 7) Sumuj wszystkie 6 wartości
    __m128 sum6 = _mm_add_ps(prod0123, prod45);
    print_m128("sum6", sum6);

    // 8) Redukcja sum6 = [s0,s1,s2,s3] -> det = s0+s1+s2+s3
    //    najpierw sum par (s0+s1, s2+s3, …)
    __m128 t1 = _mm_shuffle_ps(sum6, sum6, _MM_SHUFFLE(2,3,0,1));  // [s2,s3,s0,s1]
    __m128 sum1 = _mm_add_ps(sum6, t1);                             // [s0+s2, s1+s3, s2+s0, s3+s1]
    // drugi krok by zebrać [s0+s1+s2+s3, …]
    __m128 t2 = _mm_shuffle_ps(sum1, sum1, _MM_SHUFFLE(1,0,3,2));    // [s1+s3, s0+s2, …]
    __m128 sum2 = _mm_add_ps(sum1, t2);                             // [det, det, …]
    float det = _mm_cvtss_f32(sum2);
    printf("determinant = %.2f\n", det);

    return det;
}

int main(void) {
    float M[4][4] = {
        { 2, 3, 1, 4 },
        { 5, 8, 2, 1 },
        { 8, 7, 3, 5 },
        { 9, 4, 5, 7 }
    };
    debug_det4x4(M);
    return 0;
}

